/*
 * cave.c
 */

#include "cave.h"
#include "shaders.h"
#include "lighting.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif

static int next_gem_id = 1;

// ========== COMPLETED HELPER FUNCTIONS ==========

// Todo - Helper function to get gem color
static void getGemColor(int gemType, float col[3]) {
    switch (gemType) {
    }
}


// DONE - Perlin noise implementation
static int p[512];
static int permutation[] = {
    151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,
    190,6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
    74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,65,25,63,
    161,1,216,80,73,209,76,132,187,208,89,18,169,200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,217,226,250,124,
    123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,119,248,152,2,44,154,163,70,
    221,153,101,155,167,43,172,9,129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,246,97,228,251,34,242,193,238,
    210,144,12,191,179,162,241,81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,184,84,204,176,115,121,50,45,127,4,
    150,254,138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
};

static void init_perlin() {
    static int initialized = 0;
    if (!initialized) {
        for (int i = 0; i < 256; i++) {
            p[256 + i] = p[i] = permutation[i];
        }
        initialized = 1;
    }
}

static double fade(double t) {
    return t * t * t * (t * (t * 6 - 15) + 10);
}

static double lerp(double t, double a, double b) {
    return a + t * (b - a);
}

static double grad(int hash, double x, double y, double z) {
    int h = hash & 15;
    double u = h < 8 ? x : y;
    double v = h < 4 ? y : h == 12 || h == 14 ? x : z;
    return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
}

// DONE
float perlin_noise_3d(float x, float y, float z) {
    init_perlin();
    
    int X = (int)floor(x) & 255;
    int Y = (int)floor(y) & 255;
    int Z = (int)floor(z) & 255;
    
    x -= floor(x);
    y -= floor(y);
    z -= floor(z);
    
    double u = fade(x);
    double v = fade(y);
    double w = fade(z);
    
    int A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z;
    int B = p[X + 1] + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
    
    return lerp(w, lerp(v, lerp(u, grad(p[AA], x, y, z),
                                   grad(p[BA], x - 1, y, z)),
                           lerp(u, grad(p[AB], x, y - 1, z),
                                   grad(p[BB], x - 1, y - 1, z))),
                   lerp(v, lerp(u, grad(p[AA + 1], x, y, z - 1),
                                   grad(p[BA + 1], x - 1, y, z - 1)),
                           lerp(u, grad(p[AB + 1], x, y - 1, z - 1),
                                   grad(p[BB + 1], x - 1, y - 1, z - 1))));
}

// DONE
float fractal_noise_3d(float x, float y, float z, int octaves, float persistence) {
    float total = 0;
    float frequency = 1;
    float amplitude = 1;
    float maxValue = 0;
    
    for (int i = 0; i < octaves; i++) {
        total += perlin_noise_3d(x * frequency, y * frequency, z * frequency) * amplitude;
        maxValue += amplitude;
        amplitude *= persistence;
        frequency *= 2;
    }
    
    return total / maxValue;
}


// DONE
float distance_3d(float x1, float y1, float z1, float x2, float y2, float z2) {
    float dx = x2 - x1;
    float dy = y2 - y1;
    float dz = z2 - z1;
    return sqrt(dx*dx + dy*dy + dz*dz);
}

// TODO
void normalize_vector(float* vec) {
    }
}

// TODO
void cross_product(const float* a, const float* b, float* result) {

}



// DONE - Cave generation with barriers
void generate_cave_3d(Cave* cave) {
    srand(time(NULL));
    
    // Noise
    for (int z = 0; z < cave->depth; z++) {
        for (int y = 0; y < cave->height; y++) {
            for (int x = 0; x < cave->width; x++) {
                cave->map[z][y][x] = (rand() % 100 < WALL_THRESHOLD_PERCENTAGE) ? 1 : 0;
            }
        }
    }
    
    // Apply cellular automata rules
    for (int i = 0; i < SMOOTHING_ITERATIONS; i++) {
        smooth_cave(cave);
    }
    
    carve_cave_interior(cave);
    
    generate_height_map(cave);
    generate_normal_map(cave);
}

// TODO - Smooth cave
void smooth_cave(Cave* cave) {
    
}

// DONE - Carve cave interior
void carve_cave_interior(Cave* cave) {
    int center_x = cave->width / 2;
    int center_y = cave->height / 2;
    int center_z = cave->depth / 2;
    int chamber_radius = 15;
    
    for (int z = center_z - chamber_radius; z < center_z + chamber_radius; z++) {
        for (int y = center_y - chamber_radius; y < center_y + chamber_radius; y++) {
            for (int x = center_x - chamber_radius; x < center_x + chamber_radius; x++) {
                if (x > 0 && x < cave->width - 1 &&
                    y > 0 && y < cave->height - 1 &&
                    z > 0 && z < cave->depth - 1) {
                    float dist = sqrt(pow(x - center_x, 2) + pow(y - center_y, 2) + pow(z - center_z, 2));
                    if (dist < chamber_radius) {
                        cave->map[z][y][x] = 0;
                    }
                }
            }
        }
    }
    
    int num_tunnels = 6 + rand() % 4;
    for (int t = 0; t < num_tunnels; t++) {
        int start_x = center_x;
        int start_y = center_y;
        int start_z = center_z;
        
        float angle_h = (rand() % 360) * M_PI / 180.0f;
        float angle_v = ((rand() % 60) - 30) * M_PI / 180.0f;
        float dx = cos(angle_h) * cos(angle_v);
        float dy = sin(angle_v);
        float dz = sin(angle_h) * cos(angle_v);
        
        float x = start_x, y = start_y, z = start_z;
        int tunnel_length = 20 + rand() % 30;
        
        for (int i = 0; i < tunnel_length; i++) {
            int ix = (int)x, iy = (int)y, iz = (int)z;
            
            int radius = 3 + (rand() % 2);
            for (int sz = -radius; sz <= radius; sz++) {
                for (int sy = -radius; sy <= radius; sy++) {
                    for (int sx = -radius; sx <= radius; sx++) {
                        int px = ix + sx;
                        int py = iy + sy;
                        int pz = iz + sz;
                        
                        if (px > 0 && px < cave->width - 1 &&
                            py > 0 && py < cave->height - 1 &&
                            pz > 0 && pz < cave->depth - 1) {
                            float dist = sqrt(sx*sx + sy*sy + sz*sz);
                            if (dist <= radius) {
                                cave->map[pz][py][px] = 0;
                            }
                        }
                    }
                }
            }
            
            x += dx * 2.0f + (rand() % 3 - 1) * 0.5f;
            y += dy * 2.0f + (rand() % 3 - 1) * 0.3f;
            z += dz * 2.0f + (rand() % 3 - 1) * 0.5f;
            
            angle_h += (rand() % 40 - 20) * M_PI / 180.0f * 0.1f;
            angle_v += (rand() % 20 - 10) * M_PI / 180.0f * 0.1f;
            dx = cos(angle_h) * cos(angle_v);
            dy = sin(angle_v);
            dz = sin(angle_h) * cos(angle_v);
        }
    }
}

// TODO - Generate height map
void generate_height_map(Cave* cave) {
    for (int y = 0; y < cave->height; y++) {
        for (int x = 0; x < cave->width; x++) {
        }
    }
}

// TODO - Generate normal map
void generate_normal_map(Cave* cave) {
        }
    }
}

// ========== COMPLETED POLYHEDRON SHAPES (PROVIDED BY ASSISTANT) ==========

// DONE - Generate octahedron
void generate_octahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    *vertex_count = 6;
    *index_count = 24;
    
    float verts[] = {
         0.0f,  1.0f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -1.0f,  0.0f,  0.0f,  0.0f,  0.0f, -1.0f,  0.0f, -1.0f,  0.0f
    };
    
    memcpy(vertices, verts, sizeof(verts));
    memcpy(normals, vertices, *vertex_count * 3 * sizeof(float));
    for (int i = 0; i < *vertex_count; i++) {
        normalize_vector(&normals[i * 3]);
    }
    
    int face_indices[] = {
        0,1,2, 0,2,3, 0,3,4, 0,4,1,
        5,2,1, 5,3,2, 5,4,3, 5,1,4
    };
    
    memcpy(indices, face_indices, sizeof(face_indices));
}

// DONE - Generate dodecahedron
void generate_dodecahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    *vertex_count = 20;
    *index_count = 108;
    
    float phi = (1.0f + sqrt(5.0f)) / 2.0f;
    float inv_phi = 1.0f / phi;
    
    float verts[] = {
        // 8 vertices of a cube
         1.0f,  1.0f,  1.0f,   1.0f,  1.0f, -1.0f,   1.0f, -1.0f,  1.0f,   1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f,  1.0f,  -1.0f,  1.0f, -1.0f,  -1.0f, -1.0f,  1.0f,  -1.0f, -1.0f, -1.0f,
        // 12 vertices on edges
         0.0f,  inv_phi,  phi,   0.0f,  inv_phi, -phi,   0.0f, -inv_phi,  phi,   0.0f, -inv_phi, -phi,
         inv_phi,  phi,  0.0f,  inv_phi, -phi,  0.0f,  -inv_phi,  phi,  0.0f,  -inv_phi, -phi,  0.0f,
         phi,  0.0f,  inv_phi,  phi,  0.0f, -inv_phi, -phi,  0.0f,  inv_phi, -phi,  0.0f, -inv_phi
    };
    
    memcpy(vertices, verts, sizeof(verts));
    memcpy(normals, vertices, *vertex_count * 3 * sizeof(float));
    for (int i = 0; i < *vertex_count; i++) {
        normalize_vector(&normals[i * 3]);
    }
    
    int face_indices[] = {
        0,8,10, 0,10,12, 0,12,16, 0,16,18, 0,18,8,
        2,6,10, 2,10,8, 2,8,18, 2,18,19, 2,19,6,
        4,14,12, 4,12,10, 4,10,6, 4,6,17, 4,17,14,
        1,9,11, 1,11,13, 1,13,15, 1,15,19, 1,19,9,
        3,7,11, 3,11,9, 3,9,19, 3,19,15, 3,15,7,
        5,13,11, 5,11,7, 5,7,17, 5,17,14, 5,14,13,
        6,19,15, 6,15,13, 6,13,14, 6,14,17, 6,17,19,
        7,15,13, 8,18,16, 9,19,18, 10,12,14, 11,13,15,
        12,16,14, 13,14,15, 14,16,17, 15,17,19, 16,18,17,
        17,18,19
    };
    
    memcpy(indices, face_indices, sizeof(face_indices));
}

// DONE - Generate icosahedron
void generate_icosahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    *vertex_count = 12;
    *index_count = 60;
    
    float phi = (1.0f + sqrt(5.0f)) / 2.0f;
    
    float verts[] = {
        -1.0f,  phi,  0.0f,   1.0f,  phi,  0.0f,  -1.0f, -phi,  0.0f,   1.0f, -phi,  0.0f,
         0.0f, -1.0f,  phi,   0.0f,  1.0f,  phi,   0.0f, -1.0f, -phi,   0.0f,  1.0f, -phi,
         phi,  0.0f, -1.0f,   phi,  0.0f,  1.0f,  -phi,  0.0f, -1.0f,  -phi,  0.0f,  1.0f
    };
    
    memcpy(vertices, verts, sizeof(verts));
    memcpy(normals, vertices, *vertex_count * 3 * sizeof(float));
    for (int i = 0; i < *vertex_count; i++) {
        normalize_vector(&normals[i * 3]);
    }
    
    int face_indices[] = {
        0,11,5, 0,5,1, 0,1,7, 0,7,10, 0,10,11,
        1,5,9, 5,11,4, 11,10,2, 10,7,6, 7,1,8,
        3,9,4, 3,4,2, 3,2,6, 3,6,8, 3,8,9,
        4,9,5, 2,4,11, 6,2,10, 8,6,7, 9,8,1,
    };
    
    memcpy(indices, face_indices, sizeof(face_indices));
}

// DONE - Generate tetrahedron
void generate_tetrahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    *vertex_count = 4;
    *index_count = 12;
    
    float verts[] = {
        1.0f,  1.0f,  1.0f,   1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,  -1.0f, -1.0f,  1.0f
    };
    
    memcpy(vertices, verts, sizeof(verts));
    memcpy(normals, vertices, sizeof(verts));
    for (int i = 0; i < *vertex_count; i++) {
        normalize_vector(&normals[i * 3]);
    }
    
    int face_indices[] = {
        0, 1, 2,  0, 2, 3,  0, 3, 1,  1, 3, 2
    };
    
    memcpy(indices, face_indices, sizeof(face_indices));
}



// TODO - Render cave with tessellation
void render_cave_with_tessellation(CaveMesh* mesh) {
    
}

// TODO - Render cave interior
void render_cave_interior(Cave* cave, float cam_x, float cam_y, float cam_z) {
}

// TODO - Render crystals
void render_crystals(Crystal* crystals, int count) {
}

// TODO - Render gems
void render_gems(Gem* gems, int count, float time) {
}

// TODO - Render gem shape
void render_gem_shape(GemShape shape, float size, float* color, float* rotation, float* scale) {
}

// TODO - Render placed gems
void render_placed_gems(GemPlacementSystem* system, float time) {
}

// TODO - Render placement preview
void render_placement_preview(GemPlacementSystem* system, float time) {
}

// TODO - Render gem connections
void render_gem_connections(GemPlacementSystem* system, float time) {
}


// TODO - Create cave structure
Cave* create_cave(int width, int height, int depth) {
    // Allocate Cave structure and 3D map array
    return NULL;
}

// TODO - Free cave memory
void free_cave(Cave* cave) {
    // Free all allocated memory
}

// TODO - Find spawn point
void find_spawn_point(Cave* cave, float* x, float* y, float* z) {
    // Find empty space in cave for player spawn
    *x = 0.0f; *y = 0.0f; *z = 0.0f;
}

// TODO - Create cave mesh
CaveMesh* create_cave_mesh(Cave* cave) {
    // Generate mesh from cave data
    return NULL;
}

// TODO - Free cave mesh
void free_cave_mesh(CaveMesh* mesh) {
    // Free OpenGL resources
}

// TODO - Generate crystals
Crystal* generate_crystals(Cave* cave, int count) {
    // Place crystals near walls
    return NULL;
}

// TODO - Generate gems
Gem* generate_gems(Cave* cave, int count) {
    // Place collectible gems in cave
    return NULL;
}

// TODO - Collect gem
int collect_gem(Gem* gems, int count, float player_x, float player_y, float player_z, float collect_radius) {
    // Check if player can collect a gem
    return -1;
}

// TODO - Create gem placement system
GemPlacementSystem* create_gem_placement_system(void) {
    // Initialize placement system
    return NULL;
}

// TODO - Free gem placement system
void free_gem_placement_system(GemPlacementSystem* system) {
    // Free resources
}

// TODO - Update gem placement
void update_gem_placement(GemPlacementSystem* system, Cave* cave, float cam_x, float cam_y, float cam_z,
                         float cam_pitch, float cam_yaw, int placing_mode) {
    // Update placement preview position
}

// TODO - Place gem
int place_gem(GemPlacementSystem* system, Cave* cave, float x, float y, float z,
              int gem_type, GemShape shape) {
    // Place a gem at position
    return -1;
}

// TODO - Remove placed gem
void remove_placed_gem(GemPlacementSystem* system, int gem_id) {
    // Remove gem by ID
}

// TODO - Find nearest gem
int find_nearest_gem(GemPlacementSystem* system, float x, float y, float z, float max_distance) {
    // Find closest gem within distance
    return -1;
}

// TODO - Auto connect gems
void auto_connect_gems(GemPlacementSystem* system, int new_gem_id, float connection_range) {
    // Connect nearby gems automatically
}

// TODO - Update gem connections
void update_gem_connections(GemPlacementSystem* system, float time) {
    // Update connection animations
}

// TODO - Generate simple shapes (YOU SAID YOU'LL DO THESE)
void generate_cube_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate cube
    *vertex_count = 0;
    *index_count = 0;
}

void generate_pyramid_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate pyramid
    *vertex_count = 0;
    *index_count = 0;
}

void generate_prism_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate prism
    *vertex_count = 0;
    *index_count = 0;
}

void generate_crystal_cluster_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate crystal cluster
    *vertex_count = 0;
    *index_count = 0;
}

void generate_star_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate star
    *vertex_count = 0;
    *index_count = 0;
}

void generate_sphere_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count) {
    // Generate sphere
    *vertex_count = 0;
    *index_count = 0;
}

// TODO - Texture functions
GLuint create_texture_from_data(const float* data, int width, int height, int channels) {
    // Create OpenGL texture
    return 0;
}

// TODO - Calculate tangent space
void calculate_tangent_space(const float* v0, const float* v1, const float* v2,
                            const float* uv0, const float* uv1, const float* uv2,
                            float* tangent, float* bitangent) {
    // Calculate tangent vectors for normal mapping
}

// TODO - Water functions (if needed)
WaterPlane* create_water_plane(float size, float level) {
    return NULL;
}

void free_water_plane(WaterPlane* water) {
}

void render_water(WaterPlane* water) {
}
