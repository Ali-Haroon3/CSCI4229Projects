/*
 * cave.h - Cave Generation and Rendering (Enhanced Gem System)
 */

#ifndef CAVE_H
#define CAVE_H

#ifdef __APPLE__
#ifndef GL_SILENCE_DEPRECATION
#define GL_SILENCE_DEPRECATION
#endif
#include <OpenGL/gl3.h>
#include <OpenGL/gl3ext.h>
#else
#include <GL/glew.h>
#endif

#include <stdlib.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define CAVE_WIDTH 100
#define CAVE_HEIGHT 100
#define CAVE_DEPTH 50
#define WALL_THRESHOLD_PERCENTAGE 45
#define SMOOTHING_ITERATIONS 5
#define MIN_CAVE_SIZE 40
#define MAX_PLACED_GEMS 1000
#define MAX_GEM_CONNECTIONS 2000

// Gem shape types
typedef enum {
    GEM_SHAPE_CUBE,
    GEM_SHAPE_OCTAHEDRON,
    GEM_SHAPE_DODECAHEDRON,
    GEM_SHAPE_ICOSAHEDRON,
    GEM_SHAPE_TETRAHEDRON,
    GEM_SHAPE_PYRAMID,
    GEM_SHAPE_PRISM,
    GEM_SHAPE_CRYSTAL_CLUSTER,
    GEM_SHAPE_STAR,
    GEM_SHAPE_SPHERE,
    GEM_SHAPE_COUNT
} GemShape;

// Gem connection types
typedef enum {
    CONNECTION_NONE,
    CONNECTION_BRIDGE,     // Simple bridge between gems
    CONNECTION_CHAIN,      // Chain link connection
    CONNECTION_BEAM,       // Energy beam
    CONNECTION_CRYSTAL,    // Crystal formation
    CONNECTION_VINE,       // Organic vine-like
    CONNECTION_METAL,      // Metallic pipe/wire
    CONNECTION_COUNT
} ConnectionType;

// Cave map structure
typedef struct {
    int*** map;  // 3D cave map
    int width;
    int height;
    int depth;
    float* height_map;  // 2D height map for terrain
    float* normal_map;  // Normal map data
} Cave;

// Cave mesh structure for rendering
typedef struct {
    GLuint vao;
    GLuint vbo_vertices;
    GLuint vbo_normals;
    GLuint vbo_texcoords;
    GLuint ebo;
    GLuint height_texture;
    GLuint normal_texture;
    GLuint diffuse_texture;
    GLuint roughness_texture;
    GLuint ao_texture;
    GLuint emissive_texture;
    int index_count;
    int patch_count_x;
    int patch_count_z;
} CaveMesh;

// Crystal structure
typedef struct {
    float x, y, z;
    float size;
    float rotation;
    float color[3];
    float glow_intensity;
} Crystal;

// Enhanced Gem structure (now placeable with complex shapes)
typedef struct {
    float x, y, z;
    float rotation[3];     // Rotation around X, Y, Z axes
    float scale[3];        // Non-uniform scaling
    float bob_offset;
    int type;              // 0-9 for different gem types
    GemShape shape;        // Complex shape type
    int collected;         // Still used for collectible gems
    int placed;            // New: is this a placed gem?
    float color[3];
    float size;
    float glow_intensity;
    int connection_count;  // Number of connections to other gems
    int connected_gems[8]; // IDs of connected gems (max 8 connections per gem)
    ConnectionType connection_types[8]; // Type of each connection
    float last_interact_time; // For animation effects
    int gem_id;           // Unique identifier
} Gem;

// Gem connection structure
typedef struct {
    int gem1_id;
    int gem2_id;
    ConnectionType type;
    float strength;        // Connection strength (0.0 - 1.0)
    float animation_phase; // For animated connections
    float color[3];       // Connection color
    int active;           // Is this connection active?
    float created_time;   // When was this connection created
} GemConnection;

// Gem placement system
typedef struct {
    Gem* placed_gems;
    int placed_count;
    int max_placed;
    GemConnection* connections;
    int connection_count;
    int max_connections;
    float placement_preview_pos[3];
    int placement_mode;
    int selected_gem_type;
    GemShape selected_shape;
    ConnectionType selected_connection_type;
    int hovering_gem_id;   // ID of gem being hovered over
    float hover_time;      // How long we've been hovering
} GemPlacementSystem;

// Cave interior mode
typedef enum {
    CAVE_EXTERIOR,
    CAVE_INTERIOR
} CaveViewMode;

// Water plane
typedef struct {
    GLuint vao;
    GLuint vbo;
    GLuint reflection_fbo;
    GLuint refraction_fbo;
    GLuint reflection_texture;
    GLuint refraction_texture;
    GLuint reflection_depth;
    GLuint refraction_depth;
    GLuint dudv_texture;
    GLuint normal_texture;
    float water_level;
} WaterPlane;

// Function prototypes - Cave generation
Cave* create_cave(int width, int height, int depth);
void free_cave(Cave* cave);
void generate_cave_3d(Cave* cave);
void smooth_cave(Cave* cave);
void generate_height_map(Cave* cave);
void generate_normal_map(Cave* cave);
void carve_cave_interior(Cave* cave);
void find_spawn_point(Cave* cave, float* x, float* y, float* z);

// Cave mesh functions
CaveMesh* create_cave_mesh(Cave* cave);
void free_cave_mesh(CaveMesh* mesh);
void update_cave_mesh(CaveMesh* mesh, Cave* cave);
void render_cave_mesh(CaveMesh* mesh);
void render_cave_with_tessellation(CaveMesh* mesh);
void render_cave_interior(Cave* cave, float cam_x, float cam_y, float cam_z);

// Crystal functions
Crystal* generate_crystals(Cave* cave, int count);
void render_crystals(Crystal* crystals, int count);

// Enhanced gem functions
Gem* generate_gems(Cave* cave, int count);
void render_gems(Gem* gems, int count, float time);
void render_gem_shape(GemShape shape, float size, float* color, float* rotation, float* scale);
int collect_gem(Gem* gems, int count, float player_x, float player_y, float player_z, float collect_radius);
void respawn_gem(Gem* gem, Cave* cave);

// Gem placement system
GemPlacementSystem* create_gem_placement_system(void);
void free_gem_placement_system(GemPlacementSystem* system);
void update_gem_placement(GemPlacementSystem* system, Cave* cave, float cam_x, float cam_y, float cam_z,
                         float cam_pitch, float cam_yaw, int placing_mode);
int place_gem(GemPlacementSystem* system, Cave* cave, float x, float y, float z,
              int gem_type, GemShape shape);
void remove_placed_gem(GemPlacementSystem* system, int gem_id);
void render_placed_gems(GemPlacementSystem* system, float time);
void render_placement_preview(GemPlacementSystem* system, float time);

// Gem connection system
int create_gem_connection(GemPlacementSystem* system, int gem1_id, int gem2_id, ConnectionType type);
void remove_gem_connection(GemPlacementSystem* system, int gem1_id, int gem2_id);
void update_gem_connections(GemPlacementSystem* system, float time);
void render_gem_connections(GemPlacementSystem* system, float time);
int find_nearest_gem(GemPlacementSystem* system, float x, float y, float z, float max_distance);
void auto_connect_gems(GemPlacementSystem* system, int new_gem_id, float connection_range);

// Shape generation functions
void generate_cube_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_octahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_dodecahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_icosahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_tetrahedron_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_pyramid_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_prism_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_crystal_cluster_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_star_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);
void generate_sphere_vertices(float* vertices, float* normals, int* indices, int* vertex_count, int* index_count);

// Water functions
WaterPlane* create_water_plane(float size, float level);
void free_water_plane(WaterPlane* water);
void begin_water_reflection_pass(WaterPlane* water);
void begin_water_refraction_pass(WaterPlane* water);
void end_water_pass(void);
void render_water(WaterPlane* water);

// Texture loading
GLuint load_texture(const char* filename);
GLuint create_texture_from_data(const float* data, int width, int height, int channels);

// Utility functions
float perlin_noise_3d(float x, float y, float z);
float fractal_noise_3d(float x, float y, float z, int octaves, float persistence);
void calculate_tangent_space(const float* v0, const float* v1, const float* v2,
                            const float* uv0, const float* uv1, const float* uv2,
                            float* tangent, float* bitangent);
float distance_3d(float x1, float y1, float z1, float x2, float y2, float z2);
void normalize_vector(float* vec);
void cross_product(const float* a, const float* b, float* result);

#endif // CAVE_H
