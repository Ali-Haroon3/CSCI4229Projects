/*
 * lighting.c - Light was heavily re used from my old homeworks.
 */

#include "lighting.h"
#include "shaders.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

// Matrix math helpers
void matrix_multiply(float* result, const float* m1, const float* m2) {
    float temp[16];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            temp[i * 4 + j] = 0.0f;
            for (int k = 0; k < 4; k++) {
                temp[i * 4 + j] += m1[i * 4 + k] * m2[k * 4 + j];
            }
        }
    }
    memcpy(result, temp, 16 * sizeof(float));
}

// TODO - Main look at lighting matrix function

void matrix_look_at(float* matrix, float eye_x, float eye_y, float eye_z,
                   float center_x, float center_y, float center_z,
                   float up_x, float up_y, float up_z) 
}
// TODO matrix orthogonal view
void matrix_ortho(float* matrix, float left, float right, float bottom, float top, float near, float far) {
}
// TODO matrix perspective view
void matrix_perspective(float* matrix, float fovy, float aspect, float near, float far) {
}
// TODO create lighting system

LightingSystem* create_lighting_system(void) {
}
// TODO free lighting system

void free_lighting_system(LightingSystem* system) {
    }
}

//TODO add light
int add_light(LightingSystem* system, Light* light) {
    
}
//TODO
void remove_light(LightingSystem* system, int index) {
    
}
//TODO
void update_light(LightingSystem* system, int index, Light* light) {
}

// Shadow mapping - based off exercises
void init_shadow_mapping(LightingSystem* system) {
   
}
//TODO
void begin_shadow_pass(LightingSystem* system, int light_index) {
    
}
//TODO
void end_shadow_pass(void) {
}

//TODO
void update_light_space_matrix(LightingSystem* system, int light_index) {
}

void calculate_light_space_matrix(float* matrix, Light* light, float near, float far) {
   
}

void get_light_view_matrix(float* matrix, Light* light) {
    if (light->type == LIGHT_DIRECTIONAL) {

}

void get_light_projection_matrix(float* matrix, Light* light, float near, float far) {
    if (light->type == LIGHT_DIRECTIONAL) {
        float size = 20.0f;
        matrix_ortho(matrix, -size, size, -size, size, near, far);
    } else if (light->type == LIGHT_SPOT) {
        float fov = 2.0f * acos(light->cutoff);
        matrix_perspective(matrix, fov, 1.0f, near, far);
    } else {
        matrix_perspective(matrix, M_PI / 2.0f, 1.0f, near, far);
    }
}

// Shader setup
void set_lighting_uniforms(LightingSystem* system, GLuint shader_program) {
    glUseProgram(shader_program);
    
    // # of lights
    set_uniform_int(shader_program, "numLights", system->num_lights);
    
    // For loop to set lights
    for (int i = 0; i < system->num_lights && i < MAX_LIGHTS; i++) {
        char uniform_name[64];
        Light* light = &system->lights[i];
        
        sprintf(uniform_name, "lightPositions[%d]", i);
        glUniform3fv(glGetUniformLocation(shader_program, uniform_name), 1, light->position);
        
        sprintf(uniform_name, "lightColors[%d]", i);
        glUniform3fv(glGetUniformLocation(shader_program, uniform_name), 1, light->color);
        
        sprintf(uniform_name, "lightIntensities[%d]", i);
        glUniform1f(glGetUniformLocation(shader_program, uniform_name), light->intensity);
    }
    
    // Ambient
    set_uniform_vec3(shader_program, "ambientColor",
                     system->ambient_color[0] * system->ambient_intensity,
                     system->ambient_color[1] * system->ambient_intensity,
                     system->ambient_color[2] * system->ambient_intensity);
    
    // Uniform shadows
    set_uniform_int(shader_program, "shadowsEnabled", system->shadows_enabled);
    set_uniform_mat4(shader_program, "lightSpaceMatrix", system->light_space_matrix);
}

void bind_shadow_map(LightingSystem* system, int texture_unit) {
    glActiveTexture(GL_TEXTURE0 + texture_unit);
    glBindTexture(GL_TEXTURE_2D, system->shadow_map);
}
// TODO
void matrix_rotate_x(float* matrix, float angle) {
}
// TODO

void matrix_identity(float* m) {
}

// TODO

void matrix_rotate_y(float* matrix, float angle) {
    
}
// TODO

void matrix_translate(float* matrix, float x, float y, float z) {

}
