/*
 * ui.c - Enhanced User Interface Implementation with Gem Placement
 */

#include "ui.h"
#include "shaders.h"
#include "cave.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

// External variables for gem system
extern int gem_placement_mode;
extern int selected_gem_shape;
extern int selected_gem_type;
extern ConnectionType selected_connection_type;
extern GemPlacementSystem* gem_system;

// Enhanced UI shaders (same as before)
const char* ui_vertex_shader =
"#version 330core\n"
"layout(location = 0) in vec2 position;\n"
"layout(location = 1) in vec2 texCoord;\n"
"out vec2 TexCoord;\n"
"uniform mat4 projection;\n"
"void main() {\n"
"    gl_Position = projection * vec4(position, 0.0, 1.0);\n"
"    TexCoord = texCoord;\n"
"}\n";

const char* ui_fragment_shader =
"#version 330core\n"
"in vec2 TexCoord;\n"
"out vec4 FragColor;\n"
"uniform sampler2D uiTexture;\n"
"uniform vec4 color;\n"
"void main() {\n"
"    FragColor = texture(uiTexture, TexCoord) * color;\n"
"}\n";

const char* text_vertex_shader =
"#version 330core\n"
"layout(location = 0) in vec4 vertex;\n"
"out vec2 TexCoords;\n"
"uniform mat4 projection;\n"
"void main() {\n"
"    gl_Position = projection * vec4(vertex.xy, 0.0, 1.0);\n"
"    TexCoords = vertex.zw;\n"
"}\n";

const char* text_fragment_shader =
"#version 330core\n"
"in vec2 TexCoords;\n"
"out vec4 color;\n"
"uniform sampler2D text;\n"
"uniform vec3 textColor;\n"
"void main() {\n"
"    vec4 sampled = vec4(1.0, 1.0, 1.0, texture(text, TexCoords).r);\n"
"    color = vec4(textColor, 1.0) * sampled;\n"
"}\n";

// Shape and connection type names for display
const char* shape_names[] = {
    "Cube", "Octahedron", "Dodecahedron", "Icosahedron", "Tetrahedron",
    "Pyramid", "Prism", "Crystal Cluster", "Star", "Sphere"
};

const char* gem_type_names[] = {
    "Ruby", "Emerald", "Sapphire", "Amethyst", "Topaz",
    "Diamond", "Onyx", "Aquamarine", "Citrine", "Rose Quartz"
};

const char* connection_names[] = {
    "None", "Bridge", "Chain", "Beam", "Crystal", "Vine", "Metal"
};

UISystem* create_ui_system(void) {
    UISystem* ui = (UISystem*)calloc(1, sizeof(UISystem));
    
    init_ui_shaders();
    
    // Create crosshair
    float crosshair_verts[] = {
        -0.02f,  0.0f, 0.0f, 0.5f,
         0.02f,  0.0f, 1.0f, 0.5f,
         0.0f, -0.02f, 0.5f, 0.0f,
         0.0f,  0.02f, 0.5f, 1.0f
    };
    
    glGenVertexArrays(1, &ui->crosshair.vao);
    glGenBuffers(1, &ui->crosshair.vbo);
    glBindVertexArray(ui->crosshair.vao);
    glBindBuffer(GL_ARRAY_BUFFER, ui->crosshair.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(crosshair_verts), crosshair_verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    
    unsigned char white[] = {255, 255, 255, 255};
    glGenTextures(1, &ui->crosshair.texture);
    glBindTexture(GL_TEXTURE_2D, ui->crosshair.texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    
    ui->crosshair.visible = 1;
    
    return ui;
}

void free_ui_system(UISystem* ui) {
    if (ui) {
        glDeleteVertexArrays(1, &ui->crosshair.vao);
        glDeleteBuffers(1, &ui->crosshair.vbo);
        glDeleteTextures(1, &ui->crosshair.texture);
        glDeleteTextures(1, &ui->font_texture);
        free(ui);
    }
}

void init_ui_shaders(void) {
}

void render_text(const char* text, float x, float y, float scale) {
    glUseProgram(0);
    glColor3f(1.0f, 1.0f, 1.0f);
    glRasterPos2f(x, y);
    
    for (const char* c = text; *c; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }
}

void render_controls_overlay(int show) {
    if (!show) return;
    
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    glUseProgram(0);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    // Background panel
    glColor4f(0.0f, 0.0f, 0.0f, 0.8f);
    glBegin(GL_QUADS);
    glVertex2f(-0.9f, -0.9f);
    glVertex2f(0.9f, -0.9f);
    glVertex2f(0.9f, 0.9f);
    glVertex2f(-0.9f, 0.9f);
    glEnd();
    
    // Title
    glColor3f(1.0f, 1.0f, 1.0f);
    render_text("CAVE and Object Placement - GEM PLACEMENT", -0.4f, 0.8f, 1.5f);
    
    // Controls list
    float y_pos = 0.6f;
    const char* controls[] = {
        "MOVEMENT:",
        "  W/A/S/D - Move Forward/Left/Back/Right",
        "  Space - Jump/Fly Up",
        "  Shift - Crouch/Fly Down",
        "  Mouse - Look Around",
        "",
        "COLLECTION:",
        "  E - Collect Gem",
        "  1-9 - Select Hotbar Slot",
        "",
        "GEM PLACEMENT:",
        "  G - Toggle Gem Placement Mode",
        "  Left Click - Place Gem (in placement mode)",
        "  Right Click - Remove Nearest Gem",
        "  V - Cycle Gem Shape",
        "  B - Cycle Gem Type/Color",
        "  C - Cycle Connection Type",
        "",
        "DISPLAY:",
        "  H - Toggle This Help",
        "  P - Toggle Wireframe",
        "  T - Change Tessellation Level",
        "  L - Toggle Shadows",
        "  R - Regenerate Cave",
        "ESC - Exit Game",
        NULL
    };
    
    for (int i = 0; controls[i]; i++) {
        render_text(controls[i], -0.8f, y_pos, 1.0f);
        y_pos -= 0.05f;
    }
    
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
}

void render_ui(UISystem* ui, int window_width, int window_height) {
    GLboolean depth_test = glIsEnabled(GL_DEPTH_TEST);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    glUseProgram(0);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0, window_width, window_height, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    // Crosshair
    if (ui->crosshair.visible) {
        if (gem_placement_mode) {
            glColor4f(1.0f, 1.0f, 0.0f, 0.9f);
            glLineWidth(3.0f);
            
            glBegin(GL_LINES);
            glVertex2f(window_width/2 - 15, window_height/2);
            glVertex2f(window_width/2 + 15, window_height/2);
            glVertex2f(window_width/2, window_height/2 - 15);
            glVertex2f(window_width/2, window_height/2 + 15);
            glEnd();
            
            glBegin(GL_LINE_LOOP);
            for (int i = 0; i < 20; i++) {
                float angle = (float)i / 20.0f * 2.0f * 3.14159f;
                glVertex2f(window_width/2 + cos(angle) * 20,
                          window_height/2 + sin(angle) * 20);
            }
            glEnd();
        } else {
            glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
            glLineWidth(2.0f);
            glBegin(GL_LINES);
            glVertex2f(window_width/2 - 10, window_height/2);
            glVertex2f(window_width/2 + 10, window_height/2);
            glVertex2f(window_width/2, window_height/2 - 10);
            glVertex2f(window_width/2, window_height/2 + 10);
            glEnd();
        }
    }
    
    float hotbar_width = 500;
    float slot_size = 50;
    float hotbar_x = window_width/2 - hotbar_width/2;
    float hotbar_y = window_height - 80;
    
    for (int i = 0; i < 10; i++) {
        float x = hotbar_x + i * slot_size;
        
        if (i == ui->selected_slot) {
            glColor4f(0.8f, 0.8f, 0.2f, 0.9f);
        } else {
            glColor4f(0.2f, 0.2f, 0.2f, 0.8f);
        }
        
        glBegin(GL_QUADS);
        glVertex2f(x, hotbar_y);
        glVertex2f(x + slot_size - 2, hotbar_y);
        glVertex2f(x + slot_size - 2, hotbar_y + slot_size);
        glVertex2f(x, hotbar_y + slot_size);
        glEnd();
        
        if (ui->gem_counts[i] > 0) {
            char count_str[32];
            sprintf(count_str, "%d", ui->gem_counts[i]);
            glColor3f(1.0f, 1.0f, 1.0f);
            glRasterPos2f(x + 5, hotbar_y + slot_size - 5);
            for (char* c = count_str; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
        }
        
        glColor3f(0.8f, 0.8f, 0.8f);
        glRasterPos2f(x + 5, hotbar_y + 15);
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, '1' + i);
    }
    
    char gem_text[64];
    sprintf(gem_text, "Gems Collected: %d", ui->total_gems_collected);
    glColor3f(1.0f, 1.0f, 0.0f);
    glRasterPos2f(10, 30);
    for (char* c = gem_text; *c; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
    }
// Panel for gem placeings
    if (gem_placement_mode) {
        float panel_x = window_width - 350;
        float panel_y = 10;
        float panel_width = 340;
        float panel_height = 200;
        
        glColor4f(0.1f, 0.1f, 0.1f, 0.9f);
        glBegin(GL_QUADS);
        glVertex2f(panel_x, panel_y);
        glVertex2f(panel_x + panel_width, panel_y);
        glVertex2f(panel_x + panel_width, panel_y + panel_height);
        glVertex2f(panel_x, panel_y + panel_height);
        glEnd();
        
        glColor4f(1.0f, 1.0f, 0.0f, 1.0f);
        glLineWidth(2.0f);
        glBegin(GL_LINE_LOOP);
        glVertex2f(panel_x, panel_y);
        glVertex2f(panel_x + panel_width, panel_y);
        glVertex2f(panel_x + panel_width, panel_y + panel_height);
        glVertex2f(panel_x, panel_y + panel_height);
        glEnd();
        
        glColor3f(1.0f, 1.0f, 0.0f);
        glRasterPos2f(panel_x + 10, panel_y + 25);
        const char* title = "Gem placement mode.";
        for (const char* c = title; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }
        
        // Current selections
        glColor3f(1.0f, 1.0f, 1.0f);
        
        // Gem shape
        glRasterPos2f(panel_x + 10, panel_y + 50);
        char shape_text[64];
        sprintf(shape_text, "Shape: %s (V to change)",
                selected_gem_shape < GEM_SHAPE_COUNT ? shape_names[selected_gem_shape] : "Unknown");
        for (char* c = shape_text; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
        }
        
        // Gem type
        glRasterPos2f(panel_x + 10, panel_y + 70);
        char type_text[64];
        sprintf(type_text, "Type: %s (B to change)",
                selected_gem_type < 10 ? gem_type_names[selected_gem_type] : "Unknown");
        for (char* c = type_text; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
        }
        
        glRasterPos2f(panel_x + 10, panel_y + 90);
        char conn_text[64];
        sprintf(conn_text, "Connection: %s (C to change)",
                selected_connection_type < CONNECTION_COUNT ? connection_names[selected_connection_type] : "Unknown");
        for (char* c = conn_text; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
        }
        
        glColor3f(0.8f, 0.8f, 0.8f);
        glRasterPos2f(panel_x + 10, panel_y + 120);
        const char* instr1 = "Left Click: Place Gem";
        for (const char* c = instr1; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, *c);
        }
        
        glRasterPos2f(panel_x + 10, panel_y + 135);
        const char* instr2 = "Right Click: Remove Gem";
        for (const char* c = instr2; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, *c);
        }
        
        glRasterPos2f(panel_x + 10, panel_y + 150);
        const char* instr3 = "G: Exit Placement Mode";
        for (const char* c = instr3; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, *c);
        }
        
        // Show placed gem count
        if (gem_system) {
            glColor3f(0.2f, 1.0f, 0.2f);
            glRasterPos2f(panel_x + 10, panel_y + 175);
            char placed_text[64];
            sprintf(placed_text, "Placed Gems: %d/%d", gem_system->placed_count, gem_system->max_placed);
            for (char* c = placed_text; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
        }
    }
    
    if (gem_system && gem_system->connection_count > 0) {
        glColor3f(0.5f, 1.0f, 0.5f);
        glRasterPos2f(10, window_height - 40);
        char conn_status[64];
        sprintf(conn_status, "Active Connections: %d", gem_system->connection_count);
        for (char* c = conn_status; *c; c++) {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
        }
    }
    
    // Help text
    glColor3f(0.8f, 0.8f, 0.8f);
    glRasterPos2f(10, window_height - 20);
    const char* help_text = gem_placement_mode ?
        "Press G to exit placement mode | Press H for controls" :
        "Press G for gem placement mode | Press H for controls";
    for (const char* c = help_text; *c; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
    }
    
    // Show hover gem info
    if (gem_placement_mode && gem_system && gem_system->hovering_gem_id >= 0) {
        // Find the hovered gem
        Gem* hovered_gem = NULL;
        for (int i = 0; i < gem_system->placed_count; i++) {
            if (gem_system->placed_gems[i].gem_id == gem_system->hovering_gem_id) {
                hovered_gem = &gem_system->placed_gems[i];
                break;
            }
        }
        
        if (hovered_gem) {
            float info_x = window_width / 2 + 50;
            float info_y = window_height / 2 - 50;
            
            // Info background
            glColor4f(0.0f, 0.0f, 0.0f, 0.8f);
            glBegin(GL_QUADS);
            glVertex2f(info_x, info_y);
            glVertex2f(info_x + 200, info_y);
            glVertex2f(info_x + 200, info_y + 80);
            glVertex2f(info_x, info_y + 80);
            glEnd();
            
            glColor3f(1.0f, 1.0f, 1.0f);
            glRasterPos2f(info_x + 5, info_y + 20);
            char gem_info[64];
            sprintf(gem_info, "Gem ID: %d", hovered_gem->gem_id);
            for (char* c = gem_info; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
            
            glRasterPos2f(info_x + 5, info_y + 35);
            sprintf(gem_info, "Type: %s", gem_type_names[hovered_gem->type]);
            for (char* c = gem_info; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
            
            glRasterPos2f(info_x + 5, info_y + 50);
            sprintf(gem_info, "Shape: %s", shape_names[hovered_gem->shape]);
            for (char* c = gem_info; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
            
            glRasterPos2f(info_x + 5, info_y + 65);
            sprintf(gem_info, "Connections: %d", hovered_gem->connection_count);
            for (char* c = gem_info; *c; c++) {
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
            }
        }
    }
    
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    if (depth_test) glEnable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
}

void update_hotbar(UISystem* ui, int slot, int count) {
    if (slot >= 0 && slot < 10) {
        ui->gem_counts[slot] = count;
    }
}

void select_hotbar_slot(UISystem* ui, int slot) {
    if (slot >= 0 && slot < 10) {
        ui->selected_slot = slot;
    }
}
